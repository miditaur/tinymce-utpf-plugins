/*******************************
 * TinyMCE Plugin: Remove BR Tags
 * Author: Yurii Cherniievskyi
 * Version: 1.1.0
 * Description: Removes all <br> tags from editor content safely with undo support and removal count.
 * Created: 2026-02-15
 * Updated: 2026-07-01
 * License: MIT
 *******************************/

tinymce.PluginManager.add('remove-br-tags', function (editor) {
    const removeBrTags = function () {
        const content = editor.getContent();
        const brTags = content.match(/<br\b[^>]*>/gi);
        const count = brTags ? brTags.length : 0;

        if (count > 0) {
            const newContent = content.replace(/<br\b[^>]*>/gi, '');

            editor.undoManager.transact(function () {
                editor.setContent(newContent);
            });

            editor.windowManager.alert(count + ' &lt;br&gt; tag(s) removed.');
        } else {
            editor.windowManager.alert('No &lt;br&gt; tags found.');
        }
    };

    editor.addCommand('remove-br-tags', function () {
        removeBrTags();
    });

    editor.ui.registry.addButton('remove-br-tags', {
        text: 'BR',
        icon: 'remove',
        tooltip: 'Remove all <br> tags',
        onAction: function () {
            removeBrTags();
        }
    });
});
